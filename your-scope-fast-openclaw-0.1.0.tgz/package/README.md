# fast-openclaw

`fast-openclaw` now includes two executables:

- `fast-openclaw`: macOS one-click setup CLI for end users.
- `fast-openclaw-server`: backend + admin page for license/key management.

## Quick Start

### 1) Start backend and admin page

```bash
npm install
npm run build
FAST_OPENCLAW_ADMIN_TOKEN="change-this-token" npm run start:server
```

Default server address: `http://localhost:8787`

Admin page: `http://localhost:8787/admin`

### 2) Create a license key in admin page

- Open `/admin`
- Save admin token
- Create key
- Copy key to customer

### 3) Customer runs CLI

```bash
FAST_OPENCLAW_API_BASE="http://localhost:8787" npx @your-scope/fast-openclaw
```

The CLI asks for one-time key first. Key must validate before install/config starts.

## DingTalk 快速路径（按你的 5 步）

项目里提供了一个脚本，把以下流程一次性执行：
1. 检查/安装 Node.js
2. 安装 `openclaw@latest`
3. 安装 `openclaw-dingtalk` 插件
4. 写入 `~/.openclaw/openclaw.json`
5. 重启 gateway

执行方式：

```bash
LITELLM_API_KEY='sk-xxx' \
DING_CLIENT_ID='dingxxx' \
DING_CLIENT_SECRET='xxx' \
DING_ROBOT_CODE='dingxxx' \
DING_CORP_ID='dingxxx' \
DING_AGENT_ID='123456789' \
bash scripts/setup-dingtalk.sh
```

可选环境变量：
- `OPENCLAW_GATEWAY_TOKEN`（不传则自动生成）
- `LITELLM_BASE_URL`（默认 `http://43.134.133.185:4000/`）
- `LITELLM_API`（默认 `anthropic-messages`）
- `LITELLM_MODEL_ID`（默认 `claude-sonnet-4-6`）
- `LITELLM_MODEL_NAME`（默认 `claude-sonnet-4-6`）

脚本会自动修正插件白名单为 `openclaw-dingtalk`（不是 `dingtalk`）。

## CLI Features

- One-time license gating before setup actions.
- Resume flow with `--resume <token>` within backend time window.
- OpenClaw install + version check + PATH auto-recovery (`zsh` and `bash`).
- Pure JSON-based setup (no `openclaw onboard` interaction).
- Model preset selection from five options (OpenAI/Claude/Gemini/GLM/Kimi).
- Merge write to `~/.openclaw/openclaw.json`.
- Gateway baseline config auto-write: `mode=local`, `bind=loopback`, `port=18789`, `auth.mode=token`.
- Model connectivity test immediately after model config write.
- Browser isolated profile config when Chrome exists.
- Gateway start and token-auth connectivity verification without `openclaw agent` conversation.
- Channel bind after gateway: choose Telegram or 钉钉。
- Telegram bind: token validate -> manual chat id -> send test message.
- 钉钉 bind: plugin ensure + 5 fields write + config-level validation.
- Telegram weak validation: user sends `你是谁` and `/model`, CLI verifies inbound events are received.
- Channel scope in v1: Telegram + 钉钉。
- Standalone stage diagnostics with `--test-only` (`model|gateway|telegram|dingtalk|all`).
- Interactive doctor mode with `--doctor` to click/select checks and get troubleshooting hints.
- Session complete callback burns the one-time key.

## Server Features

- One-time license lifecycle: `NEW -> IN_USE -> USED`.
- Device fingerprint binding on first successful `start`.
- 24h resumable token window by default.
- Admin actions: create/list/disable/reset licenses.
- Built-in model schema (ChatGPT/Gemini/GLM/Claude/Kimi presets).

## Commands

```bash
# CLI
npm run dev -- --help

# Server (dev)
npm run dev:server

# Server (prod)
npm run build
npm run start:server
```

## CLI Options

```bash
fast-openclaw --api-base <url> --resume <token> --debug
```

Additional option:

- `--skip-openclaw-reset`: skip `openclaw reset --scope full` (default behavior is full reset to avoid reusing any historical config/channel state).
- `--channel <telegram|dingtalk>`: 指定渠道类型并跳过渠道选择交互。
- `--telegram-bot-token <token>`: provide Telegram bot token non-interactively.
- `--telegram-chat-id <id>`: Telegram chat id（当前为必填，支持交互输入）。
- `--dingtalk-client-id <id>`: 钉钉 clientId。
- `--dingtalk-client-secret <secret>`: 钉钉 clientSecret。
- `--dingtalk-robot-code <code>`: 钉钉 robotCode。
- `--dingtalk-corp-id <id>`: 钉钉 corpId。
- `--dingtalk-agent-id <id>`: 钉钉 agentId。
- `--skip-telegram-bind`: debug only, skip Telegram bind step.
- `--test-only <model|gateway|telegram|dingtalk|all>`: run isolated diagnostics without license/backend flow.
- `--doctor`: interactive diagnostics menu; users can select model/gateway/channel checks and see likely fixes.

Setup behavior in v1:
- CLI does not run `openclaw onboard`.
- CLI writes required baseline config directly into `~/.openclaw/openclaw.json`.
- If old `setup-state.json` contains legacy phase `onboarded`, CLI exits and requires deleting `~/.openclaw/setup-state.json` before retry.
- If old `setup-state.json` phase is `telegram_bound`, CLI auto-migrates it to `channel_bound` (`channelType=telegram`).

Doctor mode usage:

```bash
FAST_OPENCLAW_API_BASE="http://localhost:8787" npx @your-scope/fast-openclaw --doctor
```

## Setup Stage Order

Full setup flow is now:

1. `license_validated`
2. `installed`
3. `configured`: write model/browser config + gateway baseline config.
4. `model_verified`: model API connectivity test.
5. `gateway_verified`: gateway token-auth connectivity check.
6. `channel_bound`: channel bind (Telegram 或钉钉) + test/validation.
7. `completed`: backend `complete` burns one-time key.

End-user required inputs in default mode:
1. one-time license key
2. model choice + model API key (for example GLM key)
3. channel choice
4. if Telegram: bot token + chat id
5. if 钉钉: clientId/clientSecret/robotCode/corpId/agentId

## Environment Variables

### CLI

- `FAST_OPENCLAW_API_BASE`: setup backend base URL.

### Server

- `PORT` (default `8787`)
- `HOST` (default `0.0.0.0`)
- `FAST_OPENCLAW_ADMIN_TOKEN` (default `change-me`, change this in production)
- `FAST_OPENCLAW_RESUME_HOURS` (default `24`)
- `FAST_OPENCLAW_GATEWAY_URL` (optional, default gateway URL for CLI)
- `FAST_OPENCLAW_GATEWAY_TOKEN` (optional, default gateway token for CLI)
- `FAST_OPENCLAW_MODEL_PROVIDER` (optional, reorder default option in selector)
- `FAST_OPENCLAW_MODEL_API_KEY` (optional global fallback for model api key prompt)
- `FAST_OPENCLAW_MODEL_<PROVIDER>_API_KEY` (optional per-provider key default, e.g. `FAST_OPENCLAW_MODEL_GLM_API_KEY`)
- `FAST_OPENCLAW_MODEL_<PROVIDER>_BASE_URL` (optional per-provider baseUrl override)
- `FAST_OPENCLAW_MODEL_<PROVIDER>_MODEL_ID` (optional per-provider model id override)
- `FAST_OPENCLAW_MODEL_<PROVIDER>_MODEL_NAME` (optional per-provider model name override)
- `FAST_OPENCLAW_DATA_FILE` (default `./.data/store.json`)

## API Endpoints

### Setup API (used by CLI)

- `POST /v1/setup/session/start`
- `POST /v1/setup/session/resume`
- `POST /v1/setup/session/events`
- `POST /v1/setup/session/complete`

### Admin API (requires `Authorization: Bearer <admin-token>`)

- `GET /admin/api/licenses`
- `POST /admin/api/licenses`
- `POST /admin/api/licenses/:id/disable`
- `POST /admin/api/licenses/:id/reset`

## Files

- CLI resume state: `~/.openclaw/setup-state.json`
- OpenClaw config: `~/.openclaw/openclaw.json`
- Server data store: `./.data/store.json` (or `FAST_OPENCLAW_DATA_FILE`)

## Development

```bash
npm run test
npm run typecheck
npm run build
```
